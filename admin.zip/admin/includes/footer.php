  </div> <!-- content close -->
</div> <!-- d-flex close -->

<footer class="bg-dark text-white text-center py-3 mt-auto">
  &copy; <?= date("Y"); ?> My Website Admin Panel. All rights reserved.
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
