<?php
include '../db_connect.php';
session_start();
include 'includes/header.php'; // Navbar included
?>

<div class="container mt-5">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-success fw-bold">Manage Products</h2>
        <a href="add_product.php" class="btn btn-success"><i class="bi bi-plus-circle"></i> Add Product</a>
    </div>

    <!-- Search Bar -->
    <div class="input-group mb-3">
        <input type="text" id="searchInput" class="form-control" placeholder="Search by name or category...">
        <button class="btn btn-success" type="button"><i class="bi bi-search"></i></button>
    </div>

    <!-- Products Table -->
    <div class="table-responsive shadow-sm rounded">
        <table class="table table-striped table-hover align-middle text-center">
            <thead class="table-success">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price (৳)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="productTable">
                <?php
                $result = mysqli_query($conn, "SELECT p.*, c.cat_title AS cat_name FROM products p LEFT JOIN category c ON p.category_id = c.id");

                if(mysqli_num_rows($result) > 0){
                    while($row = mysqli_fetch_assoc($result)){
                        echo "<tr>
                            <td>{$row['id']}</td>
                            <td class='text-start ps-3'>{$row['name']}</td>
                            <td>{$row['cat_name']}</td>
                            <td>{$row['price']}</td>
                            <td>
                                <a href='edit_product.php?id={$row['id']}' class='btn btn-warning btn-sm me-1'><i class='bi bi-pencil-square'></i></a>
                                <a href='delete_product.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'><i class='bi bi-trash'></i></a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-muted'>No products found!</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<!-- Search Script -->
<script>
document.getElementById('searchInput').addEventListener('keyup', function(){
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#productTable tr');
    rows.forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
    });
});
</script>

<style>
.table-hover tbody tr:hover {
    background-color: #d4edda;
    transition: 0.3s;
}
.table-responsive {
    border-radius: 12px;
    overflow: hidden;
}
@media(max-width:768px){
    h2 { font-size: 20px; }
    .btn { font-size: 13px; padding: 5px 10px; }
    .table th, .table td { font-size: 14px; padding: 8px; }
}
</style>
