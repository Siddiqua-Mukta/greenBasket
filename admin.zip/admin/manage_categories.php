<?php
include '../db_connect.php';
session_start();
include 'includes/header.php';
?>

<h2 class="text-success fw-bold mb-4">Manage Categories</h2>

<div class="table-responsive">
    <table class="table table-striped table-hover align-middle text-center">
        <thead class="table-success">
            <tr>
                <th>ID</th>
                <th>Category Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM category"); // fetch all categories

            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    // adjust column name according to your DB
                    $catName = isset($row['cat_title']) ? $row['cat_title'] : ''; 

                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$catName}</td>
                        <td>
                            <a href='edit_category.php?id={$row['id']}' class='btn btn-warning btn-sm me-1'><i class='bi bi-pencil-square'></i></a>
                            <a href='delete_category.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'><i class='bi bi-trash'></i></a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='3' class='text-muted'>No categories found!</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
