<?php
include '../db_connect.php';
session_start();
include 'includes/header.php';
?>
<div class="container mt-4">
  <h3>Manage Users</h3>
  <table class="table table-bordered table-striped mt-3">
    <thead class="bg-dark text-white">
      <tr><th>ID</th><th>Name</th><th>Email</th></tr>
    </thead>
    <tbody>
      <?php
      $result = mysqli_query($conn, "SELECT * FROM users");
      while($row = mysqli_fetch_assoc($result)) {
          echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['email']}</td></tr>";
      }
      ?>
    </tbody>
  </table>
</div>
<?php include 'includes/footer.php'; ?>
